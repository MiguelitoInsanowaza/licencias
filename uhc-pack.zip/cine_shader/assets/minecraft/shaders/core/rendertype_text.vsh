#version 150

#moj_import <fog.glsl>

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV2;

uniform sampler2D Sampler2;

uniform mat4 ModelViewMat;
uniform mat4 ProjMat;
uniform int FogShape;

out float vertexDistance;
out vec4 vertexColor;
out vec2 texCoord0;

void main() {
    gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);

    vertexDistance = fog_distance(Position, FogShape);
    vertexColor = Color * texelFetch(Sampler2, UV2 / 16, 0);
    texCoord0 = UV0;

    // UHC cinematica: color (254, cols*16+col, filas*16+fila) = pedazo de video a pantalla completa
    ivec3 cc = ivec3(round(Color.rgb * 255.0));
    if (cc.r == 254 && cc.g >= 16 && cc.b >= 16) {
        float cols = float(cc.g / 16), col = float(cc.g % 16);
        float rows = float(cc.b / 16), row = float(cc.b % 16);
        int v = gl_VertexID % 4;   // 0 arriba-izq, 1 abajo-izq, 2 abajo-der, 3 arriba-der
        float x = -1.0 + 2.0 * (col + ((v == 2 || v == 3) ? 1.0 : 0.0)) / cols;
        float y = 1.0 - 2.0 * (row + ((v == 1 || v == 2) ? 1.0 : 0.0)) / rows;
        gl_Position = vec4(x, y, gl_Position.z / gl_Position.w, 1.0);
        vertexColor = vec4(1.0, 1.0, 1.0, Color.a);
    } else if ((cc.r == 63 || cc.r == 64) && cc.g >= 4 && cc.b >= 4 && cc.g <= 34 && cc.b <= 17) {
        gl_Position = vec4(2.0, 2.0, 2.0, 1.0);   // sombra de esos pedazos: fuera de pantalla
    }
}
